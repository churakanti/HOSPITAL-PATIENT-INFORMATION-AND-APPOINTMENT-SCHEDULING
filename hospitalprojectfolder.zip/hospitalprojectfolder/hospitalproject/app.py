from flask import *
import pymysql
import requests
import datetime
import base64
from requests.auth import HTTPBasicAuth


app = Flask(__name__)
app.secret_key = "eo18XmOx1ABhQO5oTms06l8vaJTW55zgZxUXykrsze9K0YMVtluzexi0TeVdFdpU"

connection = pymysql.connect(host= 'localhost', user='root', password="", database='hospital_management')




@app.route('/')
def home():
    cursor = connection.cursor()
    sql = " select * from petients where petient_name = %s "
    values = session['key']
    cursor.execute(sql, (values))
    petient_details = cursor.fetchall()

    





    return render_template('index.html', petient_details = petient_details)

@app.route('/doctor_signup', methods=['GET','POST'] )
def doctor_signup():
    if request.method == 'GET':
            return render_template('doctor_signup.html')
    else:
        doctor_name = request.form['VName']
        email = request.form['email']
        phone = request.form['contact']
        password = request.form['psw']
        password2 = request.form['psw-repeat']
        description = request.form['description']
        location = request.form['location']
        image = request.files['image']
        image.save('static/images/'+image.filename)
        image_name = image.filename

        #connection = pymysql.connect(host= 'localhost', user='root', password="", database='flask_project')
        if not doctor_name or not email or not phone:
            return render_template('doctor_signup.html', error='enter all files')
        if password != password2:
            return render_template('doctor_signup.html', error='passwords do not match')
        else:
            cursor = connection.cursor()
            sql ='''
                insert into doctors (doctor_name, doctor_email, doctor_password, doctor_contact, doctor_desc, doctor_location, doctor_image) 
                values (%s, %s, %s, %s, %s, %s, %s) 
                
                '''
            try:
                cursor.execute(sql, (doctor_name, email, password, phone, description,location, image_name))
                connection.commit()
                cursor.close()
                return render_template("doctor_signup.html", success= "You registered successfully" )
            except:
                return render_template("doctor_signup.html", error = "An error occured, registration unsuccessfull" )




@app.route('/doctor_login', methods=['GET','POST'])
def doctor_login():
    if request.method == 'GET':
            return render_template('doctor_login.html')
    else:
        doctor_email = request.form['email'] 
        password = request.form['psw']

        #connection = pymysql.connect(host= 'localhost', user='root', password="", database='flask_project')
        if not doctor_email or not password:
            return render_template('doctor_login.html', error='enter all fields')
        else:
            cursor = connection.cursor()
            sql = '''
                select * from doctors where doctor_email = %s and doctor_password = %s               

                '''
            values = (doctor_email, password)
        # try:
            cursor.execute(sql, values)

            if cursor.rowcount == 0:
                return render_template("doctor_login.html", error = "Invalid credentials" )
            else:
                session['key'] = doctor_email
                doctor = cursor.fetchone()
                session['doctor_id'] = doctor[0]
                session['desc'] = doctor[5]
                session['images'] = doctor[7]
                session['location'] = doctor[6]
                session['user_type'] = 'doctor'
                return redirect('/doctor_dashbord')

        # except:
        #     return render_template("doctor_login.html", error = "An error occured" )
            

@app.route('/user_signup', methods = ['GET', 'POST'])
def user_signup():
        if request.method == 'GET':
            return render_template('user_signup.html')
        else:
            user_name = request.form['uname']
            uemail = request.form['uemail']
            password = request.form['psw']
            password2 = request.form['psw-repeat']
            phone = request.form['phone']



            #connection = pymysql.connect(host= 'localhost', user='root', password="", database='flask_project')
            if not user_name or not uemail or not phone:
                return render_template('user_signup.html', error='enter all files')
            elif password != password2:
                return render_template('user_signup.html', error='passwords do not match')
            else:
                cursor = connection.cursor()
                sql ='''
                    insert into user (username, email, password, phone) 
                    values (%s, %s, %s, %s) 
                    
                    '''
                try:
                    cursor.execute(sql, (user_name, uemail, password, phone,))
                    connection.commit()
                    cursor.close()
                    return render_template("user_signup.html", success= "You registered successfully" )
                except:
                    return render_template("user_signup.html", error = "An error occured, registration unsuccessfull" )

@app.route('/user_login', methods=['GET','POST'])
def user_login():
    if request.method == 'GET':
            return render_template('user_login.html')
    else:
        username = request.form['uname'] 
        password = request.form['psw']

        #connection = pymysql.connect(host= 'localhost', user='root', password="", database='flask_project')
        if not username or not password:
            return render_template('user_login.html', error='enter all fields')
        else:
            cursor = connection.cursor()
            sql = '''
                select * from user where username = %s and password = %s               

                '''
            try:
                cursor.execute(sql, (username, password))
                if cursor.rowcount == 0:
                    return render_template("user_login.html", error = "Invalid credentials" )
                else:
                    user = cursor.fetchone()
                    session['key'] = username
                    session['email'] = user[1]
                    session['phone'] = user[3]
                    return redirect('/')

            except:
                return render_template("user_login.html", error = "An error occured" )
            
@app.route('/doctor_dashbord')
def doctor_dashbord():
    return render_template('doctor.html')


@app.route('/add_petient', methods=['GET','POST'] )
def add_petient():
    if 'key' not in session and 'user_type' not in session:
        return redirect('/doctor_login')

    else:
        doctor_id = session['doctor_id']
        petient_name = request.form['petient_name']
        petient_desc = request.form['petient_desc']
        petient_category = request.form["petient_category"]
        petient_bill = request.form["petient_bill"]
        petient_discount = request.form["bill_discount"]
        petient_sickness = request.form["petient_sickness"]
        image = request.files['petient_image']
        image.save('static/images/'+image.filename)
        image_name = image.filename

        #connection = pymysql.connect(host= 'localhost', user='root', password="", database='flask_project')
        if not petient_name or not petient_bill:
            return render_template('doctor.html', error='enter all files')

        else:
            cursor = connection.cursor()    
            sql ='''
                insert into petients (doctor_id, petient_name, petient_desc, petient_bill, petient_discount,petient_category, petient_sickness, image_name) 
                values (%s, %s, %s, %s, %s, %s, %s, %s) 
                
                '''
            try:
                cursor.execute(sql, (doctor_id, petient_name, petient_desc, petient_bill, petient_discount,petient_category, petient_sickness, image_name))
                connection.commit()
                cursor.close()
                return render_template ("doctor.html", success= "You successfully added a new petient" )
            except:
                return render_template("doctor.html", error = "An error occured, petient add unsuccessfull" )
            
@app.route('/single_petient/<petient_id>')
def single_petient(petient_id):

    cursor = connection.cursor()

    sql = " select * from petients where petient_id = %s "

    cursor.execute(sql, (petient_id))
    petient = cursor.fetchone()




    return render_template('single_petient.html', petient=petient )

             




@app.route('/logout')
def logout():
    session['key'] = ""
    session['email'] = ""
    session['phone'] = ""


    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)


