-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 09, 2023 at 04:53 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doctor_id` int(50) NOT NULL,
  `doctor_name` text NOT NULL,
  `doctor_email` text NOT NULL,
  `doctor_password` text NOT NULL,
  `doctor_contact` int(20) NOT NULL,
  `doctor_desc` text NOT NULL,
  `doctor_location` text NOT NULL,
  `doctor_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_id`, `doctor_name`, `doctor_email`, `doctor_password`, `doctor_contact`, `doctor_desc`, `doctor_location`, `doctor_image`) VALUES
(1, 'dr maurice', 'dr@hospital', 'opop', 9876543, 'good', 'nairobi', 'IMG-20231109-WA0013.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `petients`
--

CREATE TABLE `petients` (
  `petient_id` int(50) NOT NULL,
  `doctor_id` int(50) NOT NULL,
  `petient_name` text NOT NULL,
  `petient_desc` text NOT NULL,
  `petient_bill` int(20) NOT NULL,
  `petient_discount` text NOT NULL,
  `petient_category` text NOT NULL,
  `petient_sickness` text NOT NULL,
  `image_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petients`
--

INSERT INTO `petients` (`petient_id`, `doctor_id`, `petient_name`, `petient_desc`, `petient_bill`, `petient_discount`, `petient_category`, `petient_sickness`, `image_name`) VALUES
(1, 1, 'Mgonjwa', 'chest', 70000, '10000', 'inpetient', 'chest pain', 'medilab3.jpeg'),
(2, 1, 'Mgonjwa', 'chest pain', 700000, '10000', 'inpetient', 'chest pain', 'medilab3.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(50) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `email`, `password`, `phone`) VALUES
(1, 'maurice', 'joanbiketi@gmail.com', 'opop', 12345678),
(2, 'Mgonjwa', 'mgonjwa@m.com', 'opop', 9876543);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `petients`
--
ALTER TABLE `petients`
  ADD PRIMARY KEY (`petient_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `doctor_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `petients`
--
ALTER TABLE `petients`
  MODIFY `petient_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
